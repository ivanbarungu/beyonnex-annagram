package com.com.anagram;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnagramApplicationTests {

    @Test
    void contextLoads() {
    }

}
