package com.com.anagram.service;

import com.com.anagram.entities.AnagramPair;
import com.com.anagram.repo.AnagramPairRepository;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;

@Service
public class AnagramService {
    private final AnagramPairRepository anagramPairRepository;

    public AnagramService(AnagramPairRepository anagramPairRepository) {
        this.anagramPairRepository = anagramPairRepository;
    }

    public List<AnagramPair> getAllAnagramPairs() {
        return anagramPairRepository.findAll();
    }

    public AnagramPair saveAnagramPair(AnagramPair anagramPair) {
        return anagramPairRepository.save(anagramPair);
    }

    public boolean areAnagrams(String text1, String text2) {
        String cleanText1 = text1.replaceAll("\\s", "").toLowerCase();
        String cleanText2 = text2.replaceAll("\\s", "").toLowerCase();

        char[] charArray1 = cleanText1.toCharArray();
        char[] charArray2 = cleanText2.toCharArray();
        Arrays.sort(charArray1);
        Arrays.sort(charArray2);

        return Arrays.equals(charArray1, charArray2);
    }

}
