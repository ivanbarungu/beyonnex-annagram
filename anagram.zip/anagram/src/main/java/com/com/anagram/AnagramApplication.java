package com.com.anagram;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnagramApplication {

    public static void main(String[] args) {
        SpringApplication.run(AnagramApplication.class, args);
    }

}
