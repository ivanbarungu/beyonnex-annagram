package com.com.anagram.controller;

import com.com.anagram.entities.AnagramPair;
import com.com.anagram.service.AnagramService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class AnagramController {
    private final AnagramService anagramService;

    public AnagramController(AnagramService anagramService) {
        this.anagramService = anagramService;
    }

    @GetMapping("/areAnagrams")
    public String areAnagrams(@RequestParam String text1, @RequestParam String text2) {
        boolean result = anagramService.areAnagrams(text1, text2);
        if (result) {
            return "\"" + text1 + "\" and \"" + text2 + "\" are anagrams.";
        } else {
            return "\"" + text1 + "\" and \"" + text2 + "\" are not anagrams.";
        }
    }

    @GetMapping("/anagramPairs")
    public List<AnagramPair> getAllAnagramPairs() {
        return anagramService.getAllAnagramPairs();
    }
}
