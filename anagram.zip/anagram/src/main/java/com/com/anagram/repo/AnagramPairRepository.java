package com.com.anagram.repo;

import com.com.anagram.entities.AnagramPair;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AnagramPairRepository extends JpaRepository<AnagramPair, Long> {

}


